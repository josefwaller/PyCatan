class CatanCards:

	# the resource cards
	CARD_WOOD = 0
	CARD_BRICK = 1
	CARD_ORE = 2
	CARD_SHEEP = 3
	CARD_WHEAT = 4
	
	# the developement cards
	DEV_ROAD = 0
	DEV_VP = 1
	DEV_KNIGHT = 2
	DEV_MONOPOLY = 3
	DEV_YOP = 4